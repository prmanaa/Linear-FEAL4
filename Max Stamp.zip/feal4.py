# FEAL-4 S-Box approximation function using the SA and SB operations
def rol2(x):
    return ((x << 2) & 0xFF) | (x >> 6)

# SA(x, y) = ROL2(x + y + 1) % 256
# SB(x, y) = ROL2(x + y) % 256
def G1(x, y):
    return rol2((x + y + 1) % 256)

def G0(x, y):
    return rol2((x + y) % 256)

# XOR operation
def XOR(x, k):
    return x ^ k

# Rotation operation
def SD(x):
    return rol2(x)

# FEAL-4 f function
def fM(x):
    x0 = (x >> 24) & 0xFF
    x1 = (x >> 16) & 0xFF
    x2 = (x >> 8) & 0xFF
    x3 = x & 0xFF

    y1 = G1(x0^x1,x2^x3)
    y0 = G0(x0,y1)
    y2 = G0(y1,x2^x3)
    y3 = G1(y2,x3)

    return (y0 << 24) | (y1 << 16) | (y2 << 8) | y3

# FEAL-4 Encryption Function with k5 and k6
def feal4_encrypt(plaintext, k0,k1,k2,k3,k4,k5):
    L = (plaintext >> 32) & 0xFFFFFFFF
    R = plaintext & 0xFFFFFFFF

    # Round before
    R ^= L

    R ^= k0
    # Round 1
    L ^= fM(R)
    
    L ^= k1

    # Round 2
    R ^= fM(L)
    
    R ^= k2

    # Round 3
    L ^= fM(R)
    
    L ^= k3
    # Round 4
    R ^= fM(L)

    # Final swap
    L ^= R

    L ^= k5
    R ^= k4

    return (R << 32) | L
