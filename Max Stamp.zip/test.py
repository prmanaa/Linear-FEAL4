import csv

import feal4 as feal


def extract_bit(value, bit_position):
    """Extract the bit at the specified position from the value."""
    return (value >> bit_position) & 1

def linear_approximation(L0, R0, L4, R4, K0):
    """
    Compute the linear approximation based on the given equation.
    
    Parameters:
    L0, R0, L4, R4, K0: integers representing the respective values.
    
    Returns:
    The result of the linear approximation.
    """
    # Compute intermediate values
    term1 = L0 ^ R0 ^ L4
    term2 = L0 ^ L4 ^ R4
    term3 = feal.fM(L0 ^ R0 ^ K0)
    
    # Extract specific bits and perform XOR operations
    a = extract_bit(term1, 23) ^ extract_bit(term1, 29) ^ extract_bit(term2, 31) ^ extract_bit(term3, 31)
    
    return a

def test():
    K = 0xf6b5b8ab
    
    plaintexts = 0xaba78f5342561902
    ciphertexts = 0xeded86f49cb0d3c1
    
    P_i = plaintexts
    C_i = ciphertexts
    L0 = (P_i >> 32) & 0xFFFFFFFF
    R0 = P_i & 0xFFFFFFFF
    L4 = (C_i >> 32) & 0xFFFFFFFF
    R4 = C_i & 0xFFFFFFFF
        
    # Compute the bit j
    j = linear_approximation(L0, R0, L4, R4, K)

    return j

x = test()
print(x)