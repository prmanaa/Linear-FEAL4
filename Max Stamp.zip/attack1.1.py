import csv
import feal4 as feal

def extract_bit(value, bit_position):
    """Extract the bit at the specified position from the value."""
    return (value >> bit_position) & 1

def linear_approximation(L0, R0, L4, R4, K0):
    # Compute intermediate values
    term1 = L0 ^ R0 ^ L4
    term2 = L0 ^ L4 ^ R4
    term3 = feal.fM(L0 ^ R0 ^ K0)
    
    # Extract specific bits and perform XOR operations
    a = extract_bit(term1, 5) ^ extract_bit(term1, 13) ^ extract_bit(term1, 21) ^ extract_bit(term2, 15) ^ extract_bit(term3, 15)
    
    return a

def find_candidate_keys(csv_file_path):
    """
    Find candidate keys based on the given algorithm, brute-forcing only bits 10-15 and 18-23.
    
    Parameters:
    csv_file_path: Path to the .csv file containing plaintext-ciphertext pairs
    
    Returns:
    List of candidate keys
    """
    plaintexts = []
    ciphertexts = []
    
    # Read plaintext-ciphertext pairs from the .csv file
    with open(csv_file_path, mode='r') as file:
        csv_reader = csv.reader(file)
        next(csv_reader)  # Skip the header row
        for row in csv_reader:
            plaintexts.append(int(row[0], 16))  # Assuming plaintext is in hexadecimal
            ciphertexts.append(int(row[1], 16))  # Assuming ciphertext is in hexadecimal
    
    n = len(plaintexts)
    candidate_keys = []
    
    # Define the bit positions to brute-force
    bit_positions = list(range(10, 16)) + list(range(18, 24))  # Bits 10-15 and 18-23
    
    # Iterate over all possible 12-bit combinations for the specified bits
    for bits in range(0, 2**12):
        # Construct the key by setting only the specified bits
        K = 0
        for i, pos in enumerate(bit_positions):
            K |= ((bits >> i) & 1) << pos
        
        count = [0, 0]  # count[0] for j=0, count[1] for j=1
        
        # Iterate over all plaintext-ciphertext pairs
        for i in range(n):
            P_i = plaintexts[i]
            C_i = ciphertexts[i]
            L0 = (P_i >> 32) & 0xFFFFFFFF
            R0 = P_i & 0xFFFFFFFF
            L4 = (C_i >> 32) & 0xFFFFFFFF
            R4 = C_i & 0xFFFFFFFF
            
            # Compute the bit j
            j = linear_approximation(L0, R0, L4, R4, K)
            
            # Increment the corresponding counter
            count[j] += 1
        
        # Check if all bits j are the same
        if count[0] == n or count[1] == n:
            candidate_keys.append(K)
    
    return candidate_keys

# Example usage
csv_file_path = 'pair.csv'  # Replace with your .csv file path
candidates = find_candidate_keys(csv_file_path)
print("Candidate keys:", [hex(k) for k in candidates])